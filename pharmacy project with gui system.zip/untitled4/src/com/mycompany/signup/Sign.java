package com.mycompany.signup;

public class Sign {
}
