package com.mycompany.pharmacygui;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class OrderProcessor {

    public void placeAnOrder(int quantity, String drugName) {
        try {

            FileInputStream orderFile = new FileInputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//order.xlsx"));
            XSSFWorkbook orderWorkbook = new XSSFWorkbook(orderFile);
            XSSFSheet orderSheet = orderWorkbook.getSheetAt(0);

            FileInputStream inventoryFile = new FileInputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//pharmacy.xlsx"));
            XSSFWorkbook inventoryWorkbook = new XSSFWorkbook(inventoryFile);
            XSSFSheet inventorySheet = inventoryWorkbook.getSheetAt(0);

            boolean drugFound = false;

            for (int i = 1; i <= inventorySheet.getLastRowNum(); i++) {
                Row row = inventorySheet.getRow(i);
                Cell nameCell = row.getCell(0);
                String cellValue = nameCell.getStringCellValue().trim();

                if (cellValue.equalsIgnoreCase(drugName)) {
                    drugFound = true;
                    Cell unitPriceCell = row.getCell(2);
                    Cell categoryCell = row.getCell(3);
                    Cell quantityCell = row.getCell(4);

                    double unitPrice = unitPriceCell.getNumericCellValue();
                    double currentQuantity = quantityCell.getNumericCellValue();

                    if (currentQuantity >= quantity) {
                        if(categoryCell.getStringCellValue().equals("Cosmetics")){
                            unitPrice=unitPrice*1.2;
                            System.out.println(unitPrice);

                        }
                        if (categoryCell.getStringCellValue().equals("Prescriptions")) {
                            int option = JOptionPane.showOptionDialog(
                                    null,
                                    "Prescription required. Do you have a prescription?",
                                    "Prescription Required",
                                    JOptionPane.YES_NO_OPTION,
                                    JOptionPane.QUESTION_MESSAGE,
                                    null,
                                    new String[]{"Yes", "No"},
                                    null
                            );

                            if (option == JOptionPane.NO_OPTION) {
                                JOptionPane.showMessageDialog(null, "Sorry, you need a prescription to purchase this drug.");
                                // break;
                                option goback = new option();
                                goback.setVisible(true);
                                return;
                            } else if (option == JOptionPane.YES_OPTION) {

                                option optionFrame = new option();
                                optionFrame.setVisible(true);
                            }
                        }
                        quantityCell.setCellValue(currentQuantity - quantity);
                        double totalPrice = unitPrice * quantity;
                        Row orderRow = orderSheet.createRow(orderSheet.getLastRowNum() + 1);
                        orderRow.createCell(0).setCellValue(drugName);
                        orderRow.createCell(1).setCellValue(quantity);
                        orderRow.createCell(2).setCellValue(totalPrice);

                        JOptionPane.showMessageDialog(null, "Order placed successfully.");

                        option goback = new option();
                        goback.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Insufficient quantity available.");
                    }
                    break;
                }
            }

            if (!drugFound) {
                JOptionPane.showMessageDialog(null, "Drug not found in inventory.");
            }

            FileOutputStream inventoryOut = new FileOutputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//pharmacy.xlsx"));
            inventoryWorkbook.write(inventoryOut);
            inventoryOut.close();

            FileOutputStream orderOut = new FileOutputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//order.xlsx"));
            orderWorkbook.write(orderOut);
            orderOut.close();

            orderWorkbook.close();
            orderFile.close();
            inventoryWorkbook.close();
            inventoryFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void calculateTotalSales() {
        try {
            FileInputStream orderFile = new FileInputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//order.xlsx"));
            XSSFWorkbook orderWorkbook = new XSSFWorkbook(orderFile);
            XSSFSheet orderSheet = orderWorkbook.getSheetAt(0);

            double totalSales = 0.0;

            for (int i = 1; i <= orderSheet.getLastRowNum(); i++) {
                Row row = orderSheet.getRow(i);
                Cell priceCell = row.getCell(2);
                double totalPrice = priceCell.getNumericCellValue();
                totalSales += totalPrice;
            }

            JOptionPane.showMessageDialog(null, "Total Sales for all days: " + totalSales);

            orderWorkbook.close();
            orderFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
