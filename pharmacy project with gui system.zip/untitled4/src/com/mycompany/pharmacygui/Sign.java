package com.mycompany.pharmacygui;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Sign {
    private int capacity;
    String name;
    String password;
    String email;
    String phoneNumber;
    private List<User> users;
    private String excelFilePath ="C://Users//Toka Nabil//IdeaProjects//untitled4//signup.xlsx";
    public Sign() {
        users = new ArrayList<>();

    }
    public void registerUser(String name, String password, String email, String phoneNumber) {
        JFrame frame = new JFrame("User Registration");

        if (isEmailExists(email)) {
            JOptionPane.showMessageDialog(frame, "Email already exists. Please choose another one.");
            return;
        }
        while (password.length() < 8) {
            JPasswordField passwordField = new JPasswordField();
            int option = JOptionPane.showConfirmDialog(frame, passwordField, "Password must be at least 8 characters or numbers. Please enter a valid password:", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                password = new String(passwordField.getPassword());
            } else {
                return;
            }
        }

        User newUser = new User(name, password, email, phoneNumber);
        users.add(newUser);
        JOptionPane.showMessageDialog(frame, "Registration successful. You can now log in.");
        login2 l2 = new login2();
        l2.setVisible(true);
        saveUserToExcel(newUser);
    }
    private User findUserByName(String name) {
        for (User user : users) {

            if (user.getName().equals(name)) {
                return user;
            }
        }
        return null;
    }

    private boolean isEmailExists(String email) {
        try {
            FileInputStream file = new FileInputStream(new File(excelFilePath));
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                XSSFSheet sheet = workbook.getSheetAt(i);
                for (Row row : sheet) {
                    Cell cell = row.getCell(2); // Assuming email is in the third column (index 2)
                    if (cell != null && cell.getCellTypeEnum() == CellType.STRING && email.equals(cell.getStringCellValue())) {
                        workbook.close();
                        return true;
                    }
                }
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }
    private void saveUserToExcel(User user) {

        try {

            FileInputStream file = new FileInputStream(new File(excelFilePath));

            XSSFWorkbook workbook = new XSSFWorkbook(file); XSSFSheet sheet = workbook.getSheetAt(0);

            int rowCount = sheet.getLastRowNum();

            Row newRow = sheet.createRow(rowCount + 1);

            Cell cellFirstName = newRow.createCell(0);

            cellFirstName.setCellValue(user.getName());
            Cell cellLastName = newRow.createCell(1);

            cellLastName.setCellValue(user.getLastname());
            Cell cellEmail = newRow.createCell(2);

            cellEmail.setCellValue(user.getEmail());
            Cell cellPassword = newRow.createCell(3);

            cellPassword.setCellValue(user.getPassword());

            Cell cellPhoneNumber = newRow.createCell(4);

            cellPhoneNumber.setCellValue(user.getPhoneNumber());

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);

            workbook.write(outputStream);

            workbook.close();

            outputStream.close();

        } catch (IOException e) {

            e.printStackTrace();

        }
    }
    private static class User {
        private String name;
        private String password;
        private String phoneNumber;
        private String email;
        private String lastname;
        public User(String name, String password, String phoneNumber, String email, String lastname) {
            this.name = name;

            this.password = password;

            this.phoneNumber = phoneNumber;

            this.email = email;

            this.lastname = lastname;

        }

        public User(String name, String password, String email, String phoneNumber) {
            this.name=name;
            this.password=password;
            this.phoneNumber=phoneNumber;
            this.email=email;
        }

        public String getName() {
            return name;
        }
        public String getPassword() {
            return password;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public String getEmail() {
            return email;
        }
        public String getLastname() {
            return lastname;

        }}}