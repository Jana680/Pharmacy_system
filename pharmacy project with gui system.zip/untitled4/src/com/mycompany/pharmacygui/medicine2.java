/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pharmacygui;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.InputMismatchException;
public class medicine2 extends javax.swing.JFrame {

    public medicine2() {
        initComponents();
        centerFrame();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Name");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(280, 260, 64, 27);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Price");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(280, 320, 93, 27);

        jLabel2.setFont(new java.awt.Font("Helvetica", 1, 48));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Medicine");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(360, 20, 270, 60);

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(860, 540, 100, 31);

        jTextField1.setBackground(new java.awt.Color(0, 0, 0, 0));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder1 =new LineBorder(Color.white, 1, true);
        jTextField1.setBorder(lineBorder1 );
        jTextField1.setForeground(Color.WHITE);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1);
        jTextField1.setBounds(420, 260, 200, 30);

        jTextField2.setBackground(new java.awt.Color(0, 0, 0,0));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder2 =new LineBorder(Color.white, 1, true);
        jTextField2.setBorder(lineBorder2 );
        jTextField2.setForeground(Color.WHITE);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2);
        jTextField2.setBounds(420, 320, 200, 30);

        jTextField3.setBackground(new java.awt.Color(0, 0, 0,0));
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        LineBorder lineBorder3 =new LineBorder(Color.white, 1, true);
        jTextField3.setBorder(lineBorder3 );
        jTextField3.setForeground(Color.WHITE);
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField3);
        jTextField3.setBounds(420, 390, 200, 30);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantity");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(280, 380, 110, 40);

        jLabel4.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//pngwing.com (2).png")); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 0, 70, 110);

        jLabel3.setFont(new java.awt.Font("Caveat", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LifeLine");
        jLabel3.setToolTipText("lifeLine");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 100, 70, 20);

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//ytttyyyyyy.png")); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1010, 620);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1007, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0))
        );

        pack();
    }

    private  String jTextField1ActionPerformed(ActionEvent evt) {
        String   name = jTextField3.getText();
        return name;

    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            pharmacyy p1 = new pharmacyy();
            p1.addDrug(p1.type, Double.parseDouble(jTextField2.getText()), Integer.parseInt(jTextField3.getText()), jTextField1.getText());
            JOptionPane.showMessageDialog(this, "Drug added successfully!");

            option m1 =new option();
            m1.setVisible(true);
            this.dispose();
        } catch (InputMismatchException e) {
            JOptionPane.showMessageDialog(this, "Invalid input format!");
        }
    }

    private double jTextField2ActionPerformed(ActionEvent evt) {
        try {
            double price = Double.parseDouble(jTextField2.getText());
            return price;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input for price. Please enter a valid number.");
            return 0.0;
        }
    }
    private void centerFrame() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;
        int frameWidth = getWidth();
        int frameHeight = getHeight();
        int x = (screenWidth - frameWidth) / 2;
        int y = (screenHeight - frameHeight) / 2;
        setLocation(x,y);
    }

    private int jTextField3ActionPerformed(ActionEvent evt) {
        try {
            int quantity = Integer.parseInt(jTextField3.getText());
            return quantity;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input for quantity. Please enter a valid integer.");
            return 0;
        }
    }
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new medicine2().setVisible(true);
            }
        });
    }
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;

}