package com.mycompany.pharmacygui;
import javax.swing.border.LineBorder;
import java.awt.*;
public class signupgui extends javax.swing.JFrame {
    public signupgui() {
        initComponents();
        centerFrame();
    }
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JPasswordField();
        jTextField5 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Helvetica", 1, 48));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Sign Up");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(310, 30, 380, 60);

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 17));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));

        jButton2.setText("Sign UP");

        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(830, 550, 130, 31);

        jTextField2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder3 =new LineBorder(Color.white, 1, true);
        jTextField2.setBorder(lineBorder3 );
        jTextField2.setForeground(Color.WHITE);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2);
        jTextField2.setBounds(400, 290, 200, 30);
        jTextField3.setBackground(new java.awt.Color(0, 0, 0,0));
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder4 =new LineBorder(Color.white, 1, true);
        jTextField3.setBorder(lineBorder4 );
        jTextField3.setForeground(Color.WHITE);
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField3);
        jTextField3.setBounds(400, 210, 200, 30);

        jTextField4.setBackground(new java.awt.Color(0, 0, 0, 0));
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder1 = new LineBorder(Color.white, 1, true);
        jTextField4.setBorder(lineBorder1);
        jTextField4.setForeground(Color.WHITE);
        jTextField4.setFont(new java.awt.Font("Segoe UI", Font.BOLD, 15));

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField4);
        jTextField4.setBounds(400, 370, 200, 30);

        jTextField5.setBackground(new java.awt.Color(0, 0, 0,0));
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder6 =new LineBorder(Color.white, 1, true);
        jTextField5.setBorder(lineBorder6 );
        jTextField5.setForeground(Color.WHITE);
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField5);
        jTextField5.setBounds(400, 450, 200, 30);

        jLabel4.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//pngwing.com (2).png"));
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 0, 70, 110);

        jLabel3.setFont(new java.awt.Font("Caveat", 0, 18));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LifeLine");
        jLabel3.setToolTipText("lifeLine");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 100, 80, 40);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jLabel8.setText("Password");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(230, 370, 120, 30);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Email");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(230, 290, 60, 30);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jLabel10.setText("Phone Number");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(230, 450, 150, 30);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 20));
        jLabel12.setForeground(new java.awt.Color(204, 204, 204));
        jLabel12.setText("User Name");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(230, 210, 120, 30);

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//ytttyyyyyy.png")); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1010, 620);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1007, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0))
        );
        pack();
    }
    private void centerFrame() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;
        int frameWidth = getWidth();
        int frameHeight = getHeight();
        int x = (screenWidth - frameWidth) / 2;
        int y = (screenHeight - frameHeight) / 2;
        setLocation(x,y);
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        Sign s1=new Sign();
        s1.registerUser(jTextField3ActionPerformed( evt), jTextField4ActionPerformed(evt),jTextField2ActionPerformed(evt),jTextField5ActionPerformed( evt));
    }

    private String jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {
        String username=jTextField3.getText();
        return username;
    }
    private String jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
        String email=jTextField2.getText();
        return email;
    }
    private String jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {
        String password=jTextField4.getText();
        return password;
    }

    private String jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {
        String phone =jTextField5.getText();
        return phone;
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new signupgui().setVisible(true);
            }
        });
    }
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
}