package com.mycompany.pharmacygui;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;

class pharmacyy {

    private static int capacity;
    public static String type;
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }
    public void addDrug(String type1, double price, int quantity, String name) throws InputMismatchException {
        try {

            FileInputStream file = new FileInputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//pharmacy.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(0);
            int maxRows = sheet.getLastRowNum();
            System.out.println(capacity);
            if (maxRows >= getCapacity()) {
                JOptionPane.showMessageDialog(null, "Sorry, the pharmacy is full and cannot add any more drugs.");
                return;
            }


            Random r1 = new Random();
            int id = r1.nextInt(100);
            boolean drugExists = false;
            for (int i = 1; i <= maxRows; i++) {
                Row row = sheet.getRow(i);
                if (row.getCell(0).getCellTypeEnum() == CellType.STRING && row.getCell(0).getStringCellValue().equals(name)) {
                    int currentQuantity = (int) row.getCell(4).getNumericCellValue();
                    int option = JOptionPane.showConfirmDialog(null, "The drug already exists! Its quantity is " + currentQuantity +
                            ". Do you want to add more quantity?");
                    if (option == JOptionPane.YES_OPTION) {
                        int additionalQuantity = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter additional quantity:"));
                        row.getCell(4).setCellValue(currentQuantity + additionalQuantity);
                        drugExists = true;
                        JOptionPane.showMessageDialog(null, "Drug already exists. Quantity updated.\nThe quantity is: " + row.getCell(4));
                    } else {
                        drugExists = true;
                    }
                    break;
                }
            }
            if (!drugExists) {
                Row row = sheet.createRow(maxRows + 1);
                Cell cell1 = row.createCell(0);
                cell1.setCellValue(name);
                Cell cell2 = row.createCell(1);
                cell2.setCellValue(id);
                Cell cell3 = row.createCell(2);
                cell3.setCellValue(price);
                Cell cell4 = row.createCell(3);
                cell4.setCellValue(type1);
                Cell cell5 = row.createCell(4);
                cell5.setCellValue(quantity);
            }
            FileOutputStream fileOut = new FileOutputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//pharmacy.xlsx"));
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removeDrug(String nameToRemove) {

        try {
            FileInputStream file = new FileInputStream(new File("pharmacy.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(0);
            String removeOptionString = JOptionPane.showInputDialog("1- Remove a quantity\n2- Remove the entire row\nEnter your option:");
            int removeOption;
            if (removeOptionString != null && !removeOptionString.isEmpty()) {
                removeOption = Integer.parseInt(removeOptionString);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid option selected.");
                return;
            }
            int maxRows = sheet.getLastRowNum();
            boolean drugFound = false;
            int rowIndexToRemove = -1;
            for (int i = 1; i <= maxRows; i++) {
                Row row = sheet.getRow(i);
                if (row.getCell(0).getCellTypeEnum() == CellType.STRING && row.getCell(0).getStringCellValue().equals(nameToRemove)) {
                    drugFound = true;
                    rowIndexToRemove = i;
                    break;
                }
            }
            if (drugFound) {
                if (rowIndexToRemove == -1) {
                    JOptionPane.showMessageDialog(null, "Unexpected error occurred while trying to remove the drug.");
                } else {
                    Row rowToRemove = sheet.getRow(rowIndexToRemove);
                    if (rowToRemove == null) {
                        JOptionPane.showMessageDialog(null, "Unexpected error occurred while trying to remove the drug.");
                    } else if (removeOption == 1) {
                        String quantityToRemoveString = JOptionPane.showInputDialog("Enter quantity to remove:");
                        int quantityToRemove = Integer.parseInt(quantityToRemoveString);
                        int currentQuantity = (int) rowToRemove.getCell(4).getNumericCellValue();
                        int newQuantity = currentQuantity - quantityToRemove;
                        if (newQuantity < 0) {
                            JOptionPane.showMessageDialog(null, "Error: Quantity to remove is greater than current quantity.");
                        } else if (newQuantity == 0) {
                            sheet.removeRow(rowToRemove);
                            JOptionPane.showMessageDialog(null, "Drug removed from pharmacy successfully.");
                        } else {
                            rowToRemove.getCell(4).setCellValue(newQuantity);
                            JOptionPane.showMessageDialog(null, "Drug quantity updated successfully.");
                        }
                    } else if (removeOption == 2) {
                        sheet.removeRow(rowToRemove);
                        int lastRow = sheet.getLastRowNum();
                        if (rowIndexToRemove >= 0 && rowIndexToRemove < lastRow) {
                            sheet.shiftRows(rowIndexToRemove + 1, lastRow, -1);
                        }
                        JOptionPane.showMessageDialog(null, "Drug removed from pharmacy successfully.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid option selected.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Drug with name " + nameToRemove + " not found in pharmacy.");
            }
            FileOutputStream fileOut = new FileOutputStream(new File("pharmacy.xlsx"));
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}