package com.mycompany.pharmacygui;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class login2 extends javax.swing.JFrame {
    private JLabel outputLabel;
    JTextArea jTextArea1 = new JTextArea();

    public login2() {
        initComponents();
        outputLabel = new JLabel();
        jPanel1.add(outputLabel);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 1, 12));
        jTextArea1.setRows(3);
        jTextArea1.setEditable(false);
        centerFrame();
    }
    @SuppressWarnings("unchecked")

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jPanel1.setLayout(null);
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Email");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(270, 260, 64, 27);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Password");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(270, 320, 93, 27);

        jLabel2.setFont(new java.awt.Font("Helvetica", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Login");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(420, 30, 150, 60);

        jButton1.setBackground(new java.awt.Color(0, 0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 17));
        LineBorder lineBorder3 =new LineBorder(Color.white, 1, true);
        jButton1.setBorder(lineBorder3 );
        jButton1.setForeground(Color.WHITE);// NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Login");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    jButton1ActionPerformed(evt);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(370, 420, 100, 31);

        jButton2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 17));
        // NOI18N
        LineBorder lineBorder2 =new LineBorder(Color.white, 1, true);
        jButton2.setBorder(lineBorder2 );
        jButton2.setForeground(Color.WHITE);
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Sign Up");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(530, 420, 100, 31);

        jTextField1.setBackground(new java.awt.Color(0, 0, 0, 0));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder =new LineBorder(Color.white, 1, true);
        jTextField1.setBorder(lineBorder );
        jTextField1.setForeground(Color.WHITE);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1);
        jTextField1.setBounds(400, 260, 200, 30);

        jTextField2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LineBorder lineBorder1 = new LineBorder(Color.white, 1, true);
        jTextField2.setBorder(lineBorder1);
        jTextField2.setForeground(Color.WHITE);
        jTextField2.setFont(new java.awt.Font("Segoe UI", Font.BOLD, 15));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2);
        jTextField2.setBounds(400, 320, 200, 30);
        jLabel4.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//pngwing.com (2).png"));
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 0, 70, 110);

        jLabel3.setFont(new java.awt.Font("Caveat", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LifeLine");
        jLabel3.setToolTipText("lifeLine");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 100, 80, 20);

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon("C://Users//Toka Nabil//IdeaProjects//untitled4//src//com//mycompany//pharmacygui//ytttyyyyyy.png"));
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1010, 620);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1007, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0))
        );

        pack();
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {

    }
    private void centerFrame() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;
        int frameWidth = getWidth();
        int frameHeight = getHeight();
        int x = (screenWidth - frameWidth) / 2;
        int y = (screenHeight - frameHeight) / 2;
        setLocation(x,y);
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) throws FileNotFoundException {
        String email = jTextField1.getText();
        String password = jTextField2.getText();

        FileInputStream file = null;
        try {
            file = new FileInputStream(new File("C://Users//Toka Nabil//IdeaProjects//untitled4//signup.xlsx"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        XSSFWorkbook workbook = null;
        try {
            workbook = new XSSFWorkbook(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        XSSFSheet sheet = workbook.getSheetAt(0);

        int rowCount = sheet.getLastRowNum();

        int maxRows = sheet.getLastRowNum();
        boolean userFound = false;
        for (int i = 1; i <= maxRows; i++) {
            Row row = sheet.getRow(i);

            if (row.getCell(2).getCellTypeEnum() == CellType.STRING && row.getCell(2).getStringCellValue().equals(email) && row.getCell(3).getCellTypeEnum() == CellType.STRING && row.getCell(3).getStringCellValue().equals(password) ) {
                userFound = true;
                break;
            }
        }

        if (userFound) {
            JOptionPane.showMessageDialog(this, "Login successful. Welcome, " + email + " the main!");
            mainmenu2 mainMenu = new mainmenu2();
            mainMenu.setVisible(true);
            this.dispose();
        } else {
            int choice = JOptionPane.showConfirmDialog(this, "Invalid username or password. Do you want to sign up?", "Confirmation", JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) {
                signupgui signUpMenu = new signupgui();
                signUpMenu.setVisible(true);
                this.dispose();
            } else if (choice == JOptionPane.NO_OPTION) {
                login2 loginMenu = new login2();
                loginMenu.setVisible(true);
                this.dispose();
            }
        }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        signupgui s1 =new signupgui();
        s1.setVisible(true);
        this.dispose();
    }
    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login2().setVisible(true);
            }
        });
    }
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
}